// external js: matchHeight-initialise.js

window.onload = function () {
$('.mh1').matchHeight();
$('.mh2').matchHeight();
$('.mh3').matchHeight();
$(".loader").fadeOut("slow");
};